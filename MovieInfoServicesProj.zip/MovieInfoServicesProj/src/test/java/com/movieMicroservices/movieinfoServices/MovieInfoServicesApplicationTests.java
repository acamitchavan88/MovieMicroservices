package com.movieMicroservices.movieinfoServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieInfoServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
