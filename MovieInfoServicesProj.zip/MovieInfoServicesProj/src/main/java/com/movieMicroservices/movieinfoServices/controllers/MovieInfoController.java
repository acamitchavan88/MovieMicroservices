package com.movieMicroservices.movieinfoServices.controllers;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.movieMicroservices.movieinfoServices.model.Movie;

@RestController
@RequestMapping("/movies")
//New way of creating web requests
public class MovieInfoController {

	@RequestMapping("/{movieId}")
	public Movie getMovieInfo(@PathVariable ("movieId")String movieId)
	{
		return new Movie(1113, "DDLJ");
	}
}
